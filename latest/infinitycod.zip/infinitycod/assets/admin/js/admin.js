/**
 * InfinityCod — Interface admin
 *
 * @package InfinityCod
 * @author Derouiche Oussama
 * @copyright © Derouiche Oussama
 * @license GPL-2.0-or-later
 * @link https://derouicheoussama.com
 */
/**
 * InfinityCod — JS admin : recherche live + sauvegarde AJAX des communes.
 * Vanilla JS, aucune dépendance.
 */
(function () {
	'use strict';

	if (typeof icodAdmin === 'undefined') {
		return;
	}

	/**
	 * Recherche live dans un tableau : masque les lignes ne correspondant pas.
	 */
	function bindTableSearch(searchId, rowsSelector) {
		var input = document.getElementById(searchId);
		if (!input) {
			return;
		}

		input.addEventListener('input', function () {
			var term = input.value.trim().toLowerCase();
			var rows = document.querySelectorAll(rowsSelector);

			rows.forEach(function (row) {
				var haystack = (row.getAttribute('data-search') || '').toLowerCase();
				row.style.display = (!term || haystack.indexOf(term) !== -1) ? '' : 'none';
			});
		});
	}

	bindTableSearch('icod-wilaya-search', '.icod-wilayas-table tbody tr');
	bindTableSearch('icod-commune-search', '.icod-communes-table tbody tr');

	/**
	 * Sauvegarde immédiate (AJAX) des overrides de commune dès modification.
	 */
	var communesWrap = document.getElementById('icod-communes-wrap');
	if (communesWrap) {
		communesWrap.addEventListener('change', function (event) {
			var field = event.target.closest('.icod-commune-input');
			if (!field) {
				return;
			}

			var tr = field.closest('tr');
			var body = new window.FormData();
			body.append('action', 'icod_save_commune');
			body.append('nonce', icodAdmin.nonce);
			body.append('commune_id', tr.getAttribute('data-id'));
			body.append('field', field.getAttribute('data-field'));
			body.append('value', field.type === 'checkbox' ? (field.checked ? '1' : '0') : field.value);

			window.fetch(icodAdmin.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (response) { return response.json(); })
				.then(function (json) {
					if (!json || !json.success) {
						window.alert(icodAdmin.i18n.error);
						return;
					}
					tr.classList.add('icod-row-saved');
					window.setTimeout(function () { tr.classList.remove('icod-row-saved'); }, 900);
				})
				.catch(function () { window.alert(icodAdmin.i18n.error); });
		});
	}
	/**
	 * Tableau des commandes : tout sélectionner, détail dépliable,
	 * changements de statut rapides, blacklist.
	 */
	var checkAll = document.getElementById('icod-check-all');
	if (checkAll) {
		checkAll.addEventListener('change', function () {
			document.querySelectorAll('#icod-orders-form input[name="ids[]"]').forEach(function (box) {
				box.checked = checkAll.checked;
			});
		});
	}

	function post(action, body) {
		var data = new window.FormData();
		data.append('action', action);
		data.append('nonce', icodAdmin.nonce);
		Object.keys(body).forEach(function (key) { data.append(key, body[key]); });
		return window.fetch(icodAdmin.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
			.then(function (response) { return response.json(); });
	}

	document.querySelectorAll('.icod-quick').forEach(function (btn) {
		btn.addEventListener('click', function () {
			if (!window.confirm(icodAdmin.i18n.confirm)) { return; }
			btn.disabled = true;

			post('icod_order_status', {
				id: btn.getAttribute('data-id'),
				status: btn.getAttribute('data-status')
			}).then(function (json) {
				if (!json || !json.success) {
					window.alert(icodAdmin.i18n.error);
					btn.disabled = false;
					return;
				}
				window.location.reload();
			}).catch(function () {
				window.alert(icodAdmin.i18n.error);
				btn.disabled = false;
			});
		});
	});

	/* ===== Modale commande : détails complets + édition + tous les statuts ===== */

	/* ===== Suppression d'une commande (corbeille WC) ===== */
	document.querySelectorAll('.icod-del').forEach(function (btn) {
		btn.addEventListener('click', function () {
			if (!window.confirm('Supprimer cette commande ? Elle ira dans la corbeille WooCommerce.')) { return; }
			btn.disabled = true;
			post('icod_order_delete', { id: btn.getAttribute('data-id') }).then(function (json) {
				if (!json || !json.success) { window.alert(icodAdmin.i18n.error); btn.disabled = false; return; }
				var tr = btn.closest('tr');
				if (tr) { tr.remove(); } else { window.location.reload(); }
			}).catch(function () { window.alert(icodAdmin.i18n.error); btn.disabled = false; });
		});
	});


	var modal = document.getElementById('icod-order-modal');
	var modalBody = document.getElementById('icod-modal-body');
	var wilayas = window.icodWilayas || [];

	function escHtml(str) {
		return String(str == null ? '' : str)
			.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;').replace(/'/g, '&#039;');
	}

	function moneyAdmin(n) {
		var v = Math.round((Number(n) || 0) * 100) / 100;
		var s;
		try {
			s = new Intl.NumberFormat('fr-FR', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(v);
		} catch (e) {
			s = String(v);
		}
		return s + ' ' + (icodAdmin.currencyLabel || 'DA');
	}

	function closeModal() {
		if (!modal || modal.hidden) { return; }
		/* Fermeture animée : fondu + léger rétrécissement. */
		modal.classList.add('closing');
		window.setTimeout(function () {
			modal.hidden = true;
			modal.classList.remove('closing');
			document.body.classList.remove('icod-modal-open');
		}, 160);
	}

	function toast(msg) {
		var t = document.createElement('div');
		t.className = 'icod-toast';
		t.textContent = msg;
		document.body.appendChild(t);
		window.setTimeout(function () { t.classList.add('show'); }, 10);
		window.setTimeout(function () { t.classList.remove('show'); }, 1800);
		window.setTimeout(function () { t.remove(); }, 2200);
	}

	if (modal) {
		modal.querySelectorAll('[data-icod-modal-close]').forEach(function (el) {
			el.addEventListener('click', closeModal);
		});
		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') { closeModal(); }
		});
	}

	function openOrderModal(o) {
		if (!modal || !modalBody) { return; }

		var wa = 'https://wa.me/213' + String(o.phone || '').replace(/^0/, '');
		var risk = parseInt(o.fraud_score, 10) || 0;
		var riskLabel = risk >= 60 ? 'Élevé (' + risk + ')' : (risk >= 25 ? 'Moyen (' + risk + ')' : 'Faible');
		var riskClass = risk >= 60 ? 'icod-risk-high' : (risk >= 25 ? 'icod-risk-mid' : 'icod-risk-low');
		var modeLabel = 'desk' === o.mode ? '🏢 Au bureau' : '🏠 À domicile';

		/* Sélecteur de statuts : tous les statuts sauf le courant. */
		var statusBtns = '';
		Object.keys(o.statuses || {}).forEach(function (key) {
			if (key === o.status) { return; }
			statusBtns += '<button type="button" class="button button-small icod-m-status" data-id="' + o.id + '" data-status="' + escHtml(key) + '">' +
				escHtml(o.statuses[key]) + '</button> ';
		});

		/* Options wilayas pour l'édition. */
		var wilayaOpts = '<option value="">' + escHtml(o.wilaya_name || '—') + '</option>';
		(wilayas || []).forEach(function (w) {
			var sel = (String(w.code) === String(o.wilaya)) ? ' selected' : '';
			wilayaOpts += '<option value="' + escHtml(w.code) + '"' + sel + '>' + escHtml(w.code + ' — ' + w.name) + '</option>';
		});

		modalBody.innerHTML =
			'<div class="icod-m-head">' +
				'<h2 id="icod-modal-title">Commande #' + o.id + ' <span class="icod-sub">· ' + escHtml(o.created_at) + '</span></h2>' +
				'<span class="icod-status icod-status-' + escHtml(o.status) + '">' + escHtml((o.statuses || {})[o.status] || o.status) + '</span>' +
			'</div>' +

			'<div class="icod-m-grid">' +
				'<section class="icod-m-card">' +
					'<h4>👤 Coordonnées</h4>' +
					'<p><strong>' + escHtml(o.name) + '</strong><br />' +
					'<a href="tel:' + escHtml(o.phone) + '">' + escHtml(o.phone) + '</a> ' +
					'<button type="button" class="button button-small icod-m-copy" data-copy="' + escHtml(o.phone) + '" title="Copier">📋</button> ' +
					'<a class="button button-small" href="' + wa + '" target="_blank" rel="noopener">💬</a></p>' +
					((o.email) ? '<p class="icod-sub">✉️ ' + escHtml(o.email) + '</p>' : '') +
				'</section>' +

				'<section class="icod-m-card">' +
					'<h4>🗺️ Destination</h4>' +
					'<p>' + escHtml((o.wilaya ? o.wilaya + ' — ' : '') + (o.wilaya_name || '')) + '<br />' +
					'<span class="icod-sub">' + escHtml(o.commune) + ' · ' + modeLabel + '</span></p>' +
					((o.stopdesk) ? '<p class="icod-sub">🏢 ' + escHtml(o.stopdesk) + '</p>' : '') +
				'</section>' +

				'<section class="icod-m-card">' +
					'<h4>📦 Produit</h4>' +
					'<p>' + escHtml(o.product || '—') + '<br /><span class="icod-sub">Quantité : ×' + parseInt(o.qty, 10) + '</span></p>' +
					((parseInt(o.paid, 10)) ? '<p><span class="icod-status icod-status-confirmed">💳 Payé en ligne</span> <span class="icod-sub">' + escHtml(o.paid_at) + '</span></p>' : '') +
				'</section>' +

				'<section class="icod-m-card">' +
					'<h4>💰 Montants</h4>' +
					'<p class="icod-m-lines">' +
						'<span>Sous-total <b>' + moneyAdmin(o.subtotal) + '</b></span>' +
						((o.discount > 0) ? '<span>Remise <b>−' + moneyAdmin(o.discount) + '</b></span>' : '') +
						((o.coupon) ? '<span>Code promo <b>' + escHtml(o.coupon) + '</b></span>' : '') +
						'<span>Livraison <b>' + moneyAdmin(o.shipping) + '</b></span>' +
						'<span class="icod-m-total">Total <b>' + moneyAdmin(o.total) + '</b></span>' +
					'</p>' +
				'</section>' +

				((o.note) ? '<section class="icod-m-card icod-m-full"><h4>📝 Note</h4><p class="icod-m-note">' + escHtml(o.note) + '</p></section>' : '') +

				'<section class="icod-m-card">' +
					'<h4>🛡️ Risque & suivi</h4>' +
					'<p><span class="icod-risk ' + riskClass + '">' + escHtml(riskLabel) + '</span>' +
					((o.fraud_flags) ? ' <span class="icod-sub">⚠️ ' + escHtml(o.fraud_flags) + '</span>' : '') + '</p>' +
					'<p class="icod-sub">' +
						((o.wc_order_id) ? 'WC #' + o.wc_order_id + ' · ' : '') +
						((o.carrier) ? escHtml(o.carrier) + (o.tracking ? ' · ' + escHtml(o.tracking) : '') + (o.carrier_status ? ' · ' + escHtml(o.carrier_status) : '') : 'aucun transporteur') +
						((o.ip) ? '<br />IP : ' + escHtml(o.ip) : '') +
					'</p>' +
				'</section>' +

				'<section class="icod-m-card">' +
					'<h4>⚡ Actions</h4>' +
					'<p class="icod-m-statuses">' + statusBtns + '</p>' +
					'<p class="icod-m-actions">' +
						((o.edit_url) ? '<a class="button button-small" href="' + escHtml(o.edit_url) + '" target="_blank" rel="noopener">WooCommerce ↗</a> ' : '') +
						'<button type="button" class="button button-small" data-icod-bl-phone="' + escHtml(o.phone) + '">🚫 Blacklister</button> ' +
						'<button type="button" class="button button-small icod-m-delete" data-id="' + o.id + '">🗑 Supprimer</button>' +
					'</p>' +
				'</section>' +
			'</div>' +

			'<form class="icod-m-edit" id="icod-m-edit-form">' +
				'<h4>✎ ' + escHtml(icodAdmin.i18n.edit) + '</h4>' +
				'<div class="icod-m-edit-grid">' +
					'<label><span>Nom</span><input type="text" name="customer_name" value="' + escHtml(o.name) + '" required /></label>' +
					'<label><span>Téléphone</span><input type="text" name="phone" value="' + escHtml(o.phone) + '" dir="ltr" required /></label>' +
					'<label><span>Wilaya</span><select name="wilaya_code">' + wilayaOpts + '</select></label>' +
					'<label><span>Commune</span><input type="text" name="commune" value="' + escHtml(o.commune) + '" /></label>' +
					'<label><span>Mode</span><select name="delivery_mode">' +
						'<option value="home"' + ('home' === o.mode ? ' selected' : '') + '>À domicile</option>' +
						'<option value="desk"' + ('desk' === o.mode ? ' selected' : '') + '>Au bureau (stopdesk)</option>' +
					'</select></label>' +
					'<label><span>Bureau (si stopdesk)</span><input type="text" name="stopdesk" value="' + escHtml(o.stopdesk) + '" /></label>' +
					'<label><span>Quantité</span><input type="number" name="quantity" value="' + parseInt(o.qty, 10) + '" min="1" max="999" /></label>' +
					'<label class="icod-m-full"><span>Note</span><textarea name="note" rows="2">' + escHtml(o.note) + '</textarea></label>' +
				'</div>' +
				'<p class="icod-m-actions">' +
					'<button type="submit" class="button button-primary">' + escHtml(icodAdmin.i18n.save) + '</button> ' +
					'<button type="button" class="button" data-icod-modal-close>Fermer</button>' +
				'</p>' +
			'</form>';

		modal.hidden = false;
		document.body.classList.add('icod-modal-open');

		/* Copie du téléphone. */
		modalBody.querySelectorAll('.icod-m-copy').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var v = btn.getAttribute('data-copy') || '';
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(v).then(function () { toast('📋 Copié'); }, function () { toast(v); });
				} else { toast(v); }
			});
		});

		/* Blacklist depuis la modale. */
		modalBody.querySelectorAll('[data-icod-bl-phone]').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (!window.confirm('Blacklister ce numéro ?')) { return; }
				btn.disabled = true;
				post('icod_order_blacklist', { phone: btn.getAttribute('data-icod-bl-phone') }).then(function (json) {
					if (!json || !json.success) { window.alert(icodAdmin.i18n.error); btn.disabled = false; return; }
					toast('🚫 Numéro blacklisté');
				}).catch(function () { window.alert(icodAdmin.i18n.error); btn.disabled = false; });
			});
		});

		/* Suppression depuis la modale (corbeille WC). */
		modalBody.querySelectorAll('.icod-m-delete').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (!window.confirm('Supprimer cette commande ? Elle ira dans la corbeille WooCommerce.')) { return; }
				btn.disabled = true;
				post('icod_order_delete', { id: btn.getAttribute('data-id') }).then(function (json) {
					if (!json || !json.success) { window.alert(icodAdmin.i18n.error); btn.disabled = false; return; }
					closeModal();
					window.location.reload();
				}).catch(function () { window.alert(icodAdmin.i18n.error); btn.disabled = false; });
			});
		});

		/* Actions statut dans la modale. */
		modalBody.querySelectorAll('.icod-m-status').forEach(function (btn) {
			btn.addEventListener('click', function () {
				if (!window.confirm(icodAdmin.i18n.confirm)) { return; }
				btn.disabled = true;
				post('icod_order_status', { id: btn.getAttribute('data-id'), status: btn.getAttribute('data-status') })
					.then(function (json) {
						if (!json || !json.success) { window.alert(icodAdmin.i18n.error); btn.disabled = false; return; }
						window.location.reload();
					}).catch(function () { window.alert(icodAdmin.i18n.error); btn.disabled = false; });
			});
		});

		/* Enregistrement de l'édition. */
		var editForm = document.getElementById('icod-m-edit-form');
		if (editForm) {
			editForm.addEventListener('submit', function (event) {
				event.preventDefault();
				var submitBtn = editForm.querySelector('button[type="submit"]');
				submitBtn.disabled = true;
				submitBtn.textContent = icodAdmin.i18n.saving;

				var body = { id: o.id };
				editForm.querySelectorAll('input, select, textarea').forEach(function (input) {
					if (input.name) { body[input.name] = input.value; }
				});

				post('icod_order_update', body).then(function (json) {
					if (!json || !json.success) {
						window.alert(icodAdmin.i18n.error);
						submitBtn.disabled = false;
						submitBtn.textContent = icodAdmin.i18n.save;
						return;
					}
					window.location.reload();
				}).catch(function () {
					window.alert(icodAdmin.i18n.error);
					submitBtn.disabled = false;
					submitBtn.textContent = icodAdmin.i18n.save;
				});
			});
		}
	}

	document.querySelectorAll('.icod-open').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var payload = btn.getAttribute('data-order');
			var order = null;
			try { order = JSON.parse(payload); } catch (e) { order = null; }
			if (order) { openOrderModal(order); }
		});
	});

	document.querySelectorAll('.icod-bl').forEach(function (btn) {
		btn.addEventListener('click', function () {
			if (!window.confirm(icodAdmin.i18n.confirm)) { return; }
			btn.disabled = true;

			post('icod_order_blacklist', { phone: btn.getAttribute('data-phone') })
				.then(function (json) {
					if (!json || !json.success) {
						window.alert(icodAdmin.i18n.error);
						btn.disabled = false;
						return;
					}
					btn.textContent = '✓ ' + icodAdmin.i18n.saved;
				}).catch(function () {
					window.alert(icodAdmin.i18n.error);
					btn.disabled = false;
				});
		});
	});
	/* ===== Formulaire : synchronise la couleur d'accent avec le thème choisi ===== */

	document.querySelectorAll('.icod-preset input').forEach(function (radio) {
		radio.addEventListener('change', function () {
			var accent = document.querySelector('input[name="icod[accent_color]"]');
			if (accent && radio.getAttribute('data-accent')) {
				accent.value = radio.getAttribute('data-accent');
				/* Déclenche les événements : l'aperçu en direct se rafraîchit
				   immédiatement avec la couleur du preset. */
				['input', 'change'].forEach(function (evt) {
					accent.dispatchEvent(new window.Event(evt, { bubbles: true }));
				});
			}
		});
	});

	/* ===== Transporteurs ===== */

	// Test de connexion : envoie les champs saisis sans les enregistrer.
	document.querySelectorAll('.icod-test').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var card = btn.closest('.icod-carrier-card');
			var resultEl = document.querySelector('[data-result="' + btn.getAttribute('data-code') + '"]');
			btn.disabled = true;
			resultEl.textContent = '⏳';

			var body = { action: 'icod_carrier_test', nonce: icodAdmin.nonce, code: btn.getAttribute('data-code') };
			card.querySelectorAll('input').forEach(function (input) {
				if (input.name && input.type !== 'checkbox') {
					body[input.name.split('[').pop().replace(']', '')] = input.value;
				}
			});

			window.fetch(icodAdmin.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: new window.URLSearchParams(body).toString()
			}).then(function (res) { return res.json(); }).then(function (json) {
				btn.disabled = false;
				var payload = (json && json.data) || {};
				resultEl.textContent = (json && json.success) ? ('✅ ' + payload.message) : ('❌ ' + payload.message);
			}).catch(function () {
				btn.disabled = false;
				resultEl.textContent = '❌ ' + icodAdmin.i18n.error;
			});
		});
	});

	// Import bureaux Yalidine.
	document.querySelectorAll('.icod-import-offices').forEach(function (btn) {
		btn.addEventListener('click', function () {
			btn.disabled = true;
			btn.textContent = '⏳ ' + icodAdmin.i18n.loading;

			post('icod_import_offices', {}).then(function (json) {
				btn.disabled = false;
				var payload = (json && json.data) || {};
				btn.textContent = (json && json.success) ? '✅ ' + payload.message : '❌ ' + payload.message;
			}).catch(function () {
				btn.disabled = false;
				btn.textContent = '❌ ' + icodAdmin.i18n.error;
			});
		});
	});

	// Création de colis.
	document.querySelectorAll('.icod-ship-btn').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var cell = btn.closest('.icod-ship-cell');
			var select = cell ? cell.querySelector('.icod-ship-carrier') : null;
			var carrier = select ? select.value : '';
			if (!carrier) { return; }
			btn.disabled = true;

			post('icod_parcel_create', { id: btn.getAttribute('data-id'), carrier: carrier }).then(function (json) {
				var payload = (json && json.data) || {};
				if (json && json.success) {
					var tr = btn.closest('tr');
					tr.style.opacity = '.5';
					btn.textContent = '✅ ' + payload.tracking;
				} else {
					btn.disabled = false;
					window.alert(payload.message || icodAdmin.i18n.error);
				}
			}).catch(function () {
				btn.disabled = false;
				window.alert(icodAdmin.i18n.error);
			});
		});
	});

	// Synchronisation manuelle des suivis.
	var syncBtn = document.querySelector('.icod-sync-now');
	if (syncBtn) {
		syncBtn.addEventListener('click', function () {
			syncBtn.disabled = true;

			post('icod_sync_tracking', {}).then(function (json) {
				syncBtn.disabled = false;
				var payload = (json && json.data) || {};
				if (json && json.success) {
					window.location.reload();
				} else {
					window.alert(icodAdmin.i18n.error);
				}
			}).catch(function () {
				syncBtn.disabled = false;
				window.alert(icodAdmin.i18n.error);
			});
		});
	}
})();

/* ===== Anti double-soumission : boutons principaux désactivés au POST ===== */
document.querySelectorAll('form[action*="admin-post.php"]').forEach(function (form) {
	form.addEventListener('submit', function () {
		var button = form.querySelector('.button-primary, .button-hero');
		if (button && !button.disabled) {
			window.setTimeout(function () {
				button.disabled = true;
				button.classList.add('icod-saving');
			}, 0);
		}
	});
});

/* ===== Wilayas : filtre instantané ===== */
document.querySelectorAll('#icod-wilaya-search, #icod-commune-search').forEach(function (input) {
	input.addEventListener('input', function () {
		var q = input.value.toLowerCase();
		document.querySelectorAll('tr[data-search]').forEach(function (tr) {
			tr.style.display = tr.getAttribute('data-search').toLowerCase().indexOf(q) !== -1 ? '' : 'none';
		});
	});
});


/* ===== Réglages : sauvegarde AJAX sans rechargement + indicateur de modifications ===== */
(function () {
	'use strict';
	var form = document.querySelector('form[action*="admin-post.php"] input[value="icod_save_settings"]');
	if (!form) { return; }
	var settingsForm = form.closest('form');
	var saveBtn = settingsForm ? settingsForm.querySelector('.icod-submit .button-hero, .icod-submit .button') : null;
	var dirty = false;

	// Détecter tout changement dans les champs du formulaire.
	settingsForm.addEventListener('input', function () {
		if (!dirty) {
			dirty = true;
			if (saveBtn) { saveBtn.classList.add('icod-dirty-btn'); saveBtn.textContent = saveBtn.textContent.replace(/^● /, '● '); saveBtn.textContent = '● ' + saveBtn.textContent.replace(/^● /, ''); }
		}
	});

	// Sauvegarde AJAX : aucun rechargement, toast de confirmation.
	settingsForm.addEventListener('submit', function (e) {
		e.preventDefault();
		var body = new FormData(settingsForm);
		if (saveBtn) { saveBtn.disabled = true; saveBtn.classList.add('icod-saving'); }
		window.fetch(settingsForm.action, { method: 'POST', credentials: 'same-origin', body: body, redirect: 'manual' })
			.then(function () {
				dirty = false;
				if (saveBtn) {
					saveBtn.disabled = false;
					saveBtn.classList.remove('icod-saving', 'icod-dirty-btn');
					saveBtn.textContent = '✓ Enregistré';
					window.setTimeout(function () { saveBtn.textContent = 'Enregistrer'; }, 2000);
				}
				// Toast de confirmation.
				var toast = document.createElement('div');
				toast.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:999999;background:#0e7a4f;color:#fff;padding:12px 22px;border-radius:10px;font-weight:700;font-size:13.5px;box-shadow:0 8px 30px rgba(0,0,0,.25);animation:icod-toast-in .25s ease';
				toast.textContent = '✓ Réglages enregistrés';
				document.body.appendChild(toast);
				window.setTimeout(function () { toast.remove(); }, 2500);
			})
			.catch(function () {
				if (saveBtn) { saveBtn.disabled = false; saveBtn.classList.remove('icod-saving', 'icod-dirty-btn'); }
				window.alert(icodAdmin.i18n.error);
			});
	});

	// Avertir avant de quitter avec des modifications non enregistrées.
	window.addEventListener('beforeunload', function (e) {
		if (dirty) { e.preventDefault(); e.returnValue = ''; }
	});
})();

/* ===== Checkout Builder : glisser-déposer fluide des champs ===== */
(function () {
	var rows = document.querySelectorAll('.icod-builder-row');
	if (!rows.length) { return; }
	var dragged = null;
	function renumber() {
		document.querySelectorAll('.icod-builder-row').forEach(function (row, idx) {
			row.querySelectorAll('input, select').forEach(function (inp) {
				inp.name = inp.name.replace(/icod\[checkout_fields\]\[\d+\]/, 'icod[checkout_fields][' + idx + ']');
			});
			var h = row.querySelector('input[type=hidden][name*=order]');
			if (h) { h.value = idx; }
		});
	}
	rows.forEach(function (row) {
		var handle = row.querySelector('.icod-bdrag');
		if (!handle) { return; }
		handle.addEventListener('mousedown', function () { row.draggable = true; });
		handle.addEventListener('mouseup', function () { row.draggable = false; });
		row.addEventListener('dragstart', function (e) {
			dragged = row;
			row.classList.add('dragging');
			e.dataTransfer.effectAllowed = 'move';
			try { e.dataTransfer.setData('text/plain', ''); } catch (err) {}
		});
		row.addEventListener('dragend', function () {
			row.classList.remove('dragging');
			row.draggable = false;
			renumber();
		});
		row.addEventListener('dragover', function (e) {
			e.preventDefault();
			if (!dragged || dragged === row) { return; }
			var rect = row.getBoundingClientRect();
			var after = (e.clientY - rect.top) > rect.height / 2;
			row.parentNode.insertBefore(dragged, after ? row.nextSibling : row);
		});
	});
})();

/* ===== Commandes : recherche fluide + confirmation suppression groupée ===== */
(function () {
	var bulkForm = document.getElementById('icod-orders-form');
	if (bulkForm) {
		bulkForm.addEventListener('submit', function (e) {
			var sel = document.getElementById('icod-bulk-action');
			if (sel && sel.value === 'delete' && !window.confirm(bulkForm.getAttribute('data-confirm-delete') || 'Supprimer ?')) {
				e.preventDefault();
			}
		});
	}
	var search = document.querySelector('.icod-orders-filters input[name=q]');
	var filterForm = search ? search.closest('form') : null;
	if (search && filterForm) {
		var t = null;
		search.addEventListener('input', function () {
			clearTimeout(t);
			t = window.setTimeout(function () { filterForm.submit(); }, 700);
		});
	}
})();
