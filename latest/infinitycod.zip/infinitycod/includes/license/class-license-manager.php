<?php
/**
 * Licence : activation et vérification auprès du serveur Infinity Coder
 * (protocole du serveur de licences Infinity Coder).
 *
 * Produit gratuit de base ; la licence débloque WhatsApp automatique,
 * transporteurs, statistiques P&L et offres avancées.
 *
 * @package InfinityCod
 * @author Derouiche Oussama
 * @copyright © Derouiche Oussama
 * @link https://derouicheoussama.com
 */

namespace InfinityCod\License;

use InfinityCod\Core\Settings;

defined( 'ABSPATH' ) || exit;

class LicenseManager {

	const OPTION       = 'infinitycod_license';
	const TRIAL_OPTION = 'infinitycod_trial';
	/**
	 * Préfixe des clés signées hors ligne (Ed25519, émises par l'éditeur) :
	 * ICOD1.<payload base64url>.<signature base64url>.
	 */
	const KEY_PREFIX = 'ICOD1.';

	const TRIAL_DAYS = 7;

	/**
	 * Url du serveur de licences (modifiable, ex. copie dédiée).
	 *
	 * @return string
	 */
	public static function server_url() {
		$url = (string) Settings::get( 'license_server', 'https://infinitycoder.app/api.php' );

		// Migration défensive : les anciennes installations pointant vers
		// factexpert.online sont redirigées vers le domaine Infinity Coder.
		if ( '' === trim( $url ) || false !== strpos( $url, 'factexpert.online' ) ) {
			$url = 'https://infinitycoder.app/api.php';
		}

		/**
		 * Url de l'API du serveur de licences Infinity Coder.
		 *
		 * @param string $url Url par défaut.
		 */
		return apply_filters( 'infinitycod_license_server_url', $url );
	}

	/**
	 * Hooks : vérification hebdomadaire.
	 *
	 * @return void
	 */
	public function register() {
		add_action( 'infinitycod_license_heartbeat', array( $this, 'heartbeat' ) );

		if ( ! wp_next_scheduled( 'infinitycod_license_heartbeat' ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', 'infinitycod_license_heartbeat' );
		}

		// Mises à jour à distance via l'API standard WordPress.
		( new Updater() )->register();
	}

	/**
	 * Données de licence stockées.
	 *
	 * @return array
	 */
	public static function stored() {
		$data = get_option( self::OPTION, array() );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * Identifiant machine : empreinte du site (un site = une machine).
	 *
	 * @return string
	 */
	public static function machine_id() {
		return hash( 'sha256', home_url( '/' ) . '|' . get_option( 'infinitycod_install_id', '' ) );
	}

	/**
	 * Identifiant d'installation stable.
	 *
	 * @return string
	 */
	public static function install_id() {
		$install_id = get_option( 'infinitycod_install_id', '' );
		if ( ! $install_id ) {
			$install_id = wp_generate_password( 24, false, false );
			update_option( 'infinitycod_install_id', $install_id, true );
		}
		return $install_id;
	}

	/**
	 * Active une clé de licence.
	 *
	 * @param string $key Clé fournie par le marchand.
	 * @return array{ok: bool, message: string}
	 */
	public function activate( $key ) {
		$key = trim( (string) $key );

		if ( '' === $key ) {
			return array( 'ok' => false, 'message' => __( 'Veuillez saisir votre clé de licence.', 'infinitycod' ) );
		}

		// Clés signées Ed25519 hors ligne (ICOD1.…) : émises par l'éditeur,
		// vérifiables SANS serveur — la clé publique est embarquée dans le
		// plugin. Couvre les clés de test du développeur et les ventes
		// traitées manuellement ou via un webhook de paiement.
		if ( 0 === strpos( $key, self::KEY_PREFIX ) ) {
			$data = self::verify_offline_key( $key );
			if ( null === $data ) {
				return array( 'ok' => false, 'message' => __( 'Clé signée invalide ou expirée.', 'infinitycod' ) );
			}
			update_option( self::OPTION, array(
				'key_hash'   => hash( 'sha256', $key ),
				'status'     => 'ACTIVE',
				'client'     => (string) ( isset( $data['client'] ) ? $data['client'] : '' ),
				'email'      => (string) ( isset( $data['email'] ) ? $data['email'] : '' ),
				'expires_at' => (string) ( isset( $data['expires'] ) ? $data['expires'] : '' ),
				'offline'    => true,
				'checked_at' => current_time( 'mysql' ),
			), true );
			return array(
				'ok'      => true,
				/* translators: 1 : type de licence, 2 : date d'expiration. */
				'message' => sprintf( __( 'Licence %1$s activée — valable jusqu‘au %2$s.', 'infinitycod' ), (string) ( isset( $data['type'] ) ? $data['type'] : 'pro' ), (string) ( isset( $data['expires'] ) ? $data['expires'] : '' ) ),
			);
		}

		// Clé de développement : uniquement si INFINITYCOD_DEV_MODE est défini
		// dans wp-config.php (jamais actif dans la build commerciale).
		if ( hash_equals( 'INFINITY-DEV', $key ) ) {
			if ( ! defined( 'INFINITYCOD_DEV_MODE' ) || ! INFINITYCOD_DEV_MODE ) {
				return array( 'ok' => false, 'message' => __( 'Clé de développement non autorisée sur ce site.', 'infinitycod' ) );
			}
			update_option( self::OPTION, array(
				'key_hash'   => hash( 'sha256', $key ),
				'status'     => 'ACTIVE',
				'client'     => 'Development',
				'expires_at' => '',
				'checked_at' => current_time( 'mysql' ),
			), true );
			return array( 'ok' => true, 'message' => __( 'Licence de développement activée.', 'infinitycod' ) );
		}

		self::install_id();

		$response = wp_remote_post(
			add_query_arg( 'action', 'activate', self::server_url() ),
			array(
				'timeout' => 20,
				'body'    => array(
					'machine'    => self::machine_id(),
					'key_hash'   => hash( 'sha256', $key ),
					'install_id' => self::install_id(),
					'product'    => 'infinitycod',
					'version'    => INFINITYCOD_VERSION,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'message' => $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$body = is_array( $body ) ? $body : array();
		$status = isset( $body['status'] ) ? (string) $body['status'] : 'INVALID';

		if ( 'ACTIVE' === $status ) {
			update_option( self::OPTION, array(
				'key_hash'   => hash( 'sha256', $key ),
				'status'     => 'ACTIVE',
				'client'     => isset( $body['client'] ) ? (string) $body['client'] : '',
				'email'      => isset( $body['email'] ) ? (string) $body['email'] : '',
				'expires_at' => isset( $body['expires_at'] ) ? (string) $body['expires_at'] : '',
				'checked_at' => current_time( 'mysql' ),
			), true );

			return array(
				'ok' => true,
				/* translators: %s : nom du client titulaire. */
				'message' => sprintf( __( 'Licence activée. Merci %s !', 'infinitycod' ), isset( $body['client'] ) ? $body['client'] : '' ),
			);
		}

		$message = isset( $body['message'] ) ? (string) $body['message'] : '';
		return array(
			'ok' => false,
			/* translators: %s : statut renvoyé par le serveur. */
			'message' => sprintf( __( 'Activation refusée (%1$s). %2$s', 'infinitycod' ), $status, $message ),
		);
	}

	/**
	 * Requête vers le serveur de licences.
	 *
	 * @param string $action   Action API (activate, heartbeat, deactivate).
	 * @param string $key_hash Empreinte SHA-256 de la clé.
	 * @return array|WP_Error Réponse HTTP ou erreur.
	 */
	private function remote_status( $action, $key_hash ) {
		return wp_remote_post(
			add_query_arg( 'action', $action, self::server_url() ),
			array(
				'timeout' => 20,
				'body'    => array(
					'machine'    => self::machine_id(),
					'key_hash'   => $key_hash,
					'install_id' => self::install_id(),
					'product'    => 'infinitycod',
					'version'    => INFINITYCOD_VERSION,
				),
			)
		);
	}

	/**
	 * Vérification périodique (tâche hebdomadaire).
	 *
	 * @return void
	 */
	public function heartbeat() {
		$stored = self::stored();
		if ( empty( $stored['key_hash'] ) ) {
			return;
		}

		// Licence hors ligne signée : rien à synchroniser avec un serveur.
		if ( ! empty( $stored['offline'] ) ) {
			return;
		}

		$response = $this->remote_status( 'heartbeat', $stored['key_hash'] );

		if ( is_wp_error( $response ) ) {
			return; // Serveur injoignable : statut conservé.
		}

		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		$body   = is_array( $body ) ? $body : array();
		$status = isset( $body['status'] ) ? (string) $body['status'] : '';

		if ( '' !== $status ) {
			$stored['status']     = $status;
			$stored['checked_at'] = current_time( 'mysql' );
			update_option( self::OPTION, $stored, true );
		}
	}

	/**
	 * Vérification manuelle déclenchée depuis l'écran Licence.
	 *
	 * @return array{ok: bool, message: string}
	 */
	public function manual_check() {
		$stored = self::stored();

		if ( empty( $stored['key_hash'] ) ) {
			return array( 'ok' => false, 'message' => __( 'Aucune clé enregistrée : activez d’abord votre licence.', 'infinitycod' ) );
		}

		// Licence hors ligne signée : validité recalculée localement.
		if ( ! empty( $stored['offline'] ) ) {
			$stored['checked_at'] = current_time( 'mysql' );
			update_option( self::OPTION, $stored, true );
			if ( ! empty( $stored['expires_at'] ) && $stored['expires_at'] < gmdate( 'Y-m-d' ) ) {
				return array( 'ok' => false, 'message' => __( 'Licence hors ligne expirée — demandez une nouvelle clé à l‘éditeur.', 'infinitycod' ) );
			}
			return array(
				'ok'      => true,
				/* translators: %s : date d'expiration. */
				'message' => sprintf( __( 'Licence hors ligne valide jusqu‘au %s (signature vérifiée localement).', 'infinitycod' ), (string) $stored['expires_at'] ),
			);
		}

		$response = $this->remote_status( 'heartbeat', $stored['key_hash'] );

		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'message' => __( 'Serveur de licences injoignable. Votre statut local est conservé (période de grâce).', 'infinitycod' ) );
		}

		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		$body   = is_array( $body ) ? $body : array();
		$status = isset( $body['status'] ) ? (string) $body['status'] : '';

		if ( '' === $status ) {
			return array( 'ok' => false, 'message' => __( 'Réponse inattendue du serveur de licences.', 'infinitycod' ) );
		}

		$stored['status']     = $status;
		$stored['checked_at'] = current_time( 'mysql' );
		if ( ! empty( $body['expires_at'] ) ) {
			$stored['expires_at'] = (string) $body['expires_at'];
		}
		update_option( self::OPTION, $stored, true );

		if ( 'ACTIVE' === $status ) {
			return array( 'ok' => true, 'message' => __( 'Licence vérifiée auprès du serveur : active.', 'infinitycod' ) );
		}

		if ( 'UNKNOWN' === $status ) {
			return array( 'ok' => true, 'message' => __( 'Serveur injoignable : statut conservé (période de grâce).', 'infinitycod' ) );
		}

		/* translators: %s : statut renvoyé par le serveur. */
		return array( 'ok' => false, 'message' => sprintf( __( 'Le serveur indique le statut : %s.', 'infinitycod' ), $status ) );
	}

	/**
	 * Désactive la licence localement (et libère le siège côté serveur).
	 *
	 * @return array{ok: bool, message: string}
	 */
	public function deactivate() {
		$stored = self::stored();

		if ( empty( $stored['key_hash'] ) ) {
			return array( 'ok' => false, 'message' => __( 'Aucune licence active à désactiver.', 'infinitycod' ) );
		}

		// Best effort : prévenir le serveur pour libérer la machine.
		wp_remote_post(
			add_query_arg( 'action', 'deactivate', self::server_url() ),
			array(
				'timeout' => 10,
				'body'    => array(
					'machine'    => self::machine_id(),
					'key_hash'   => $stored['key_hash'],
					'install_id' => self::install_id(),
					'product'    => 'infinitycod',
				),
			)
		);

		delete_option( self::OPTION );

		return array(
			'ok'      => true,
			'message' => __( 'Licence désactivée. Les fonctionnalités Premium sont verrouillées ; vos données (commandes, tarifs, réglages) sont conservées.', 'infinitycod' ),
		);
	}

	/**
	 * Les fonctionnalités premium sont-elles débloquées ?
	 *
	 * Tolérance hors-ligne : une licence UNKNOWN (serveur injoignable lors
	 * de la dernière vérification réussie) reste active, comme le protocole
	 * du serveur le prévoit. Un essai gratuit en cours débloque aussi tout.
	 *
	 * @return bool
	 */
	public static function is_premium() {
		/**
		 * Court-circuite le contrôle de licence (tests, distributions spéciales).
		 *
		 * @param bool|null $override Null = contrôle normal.
		 */
		$override = apply_filters( 'infinitycod_premium_override', null );
		if ( null !== $override ) {
			return (bool) $override;
		}

		if ( self::trial_active() ) {
			return true;
		}

		$stored = self::stored();
		if ( empty( $stored['key_hash'] ) || ! in_array( isset( $stored['status'] ) ? $stored['status'] : '', array( 'ACTIVE', 'UNKNOWN' ), true ) ) {
			return false;
		}

		// Licence hors ligne signée : expire localement, sans serveur.
		if ( ! empty( $stored['offline'] ) && ! empty( $stored['expires_at'] ) && $stored['expires_at'] < gmdate( 'Y-m-d' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Vérifie une clé signée Ed25519 hors ligne (format ICOD1.…).
	 *
	 * @param string $key Clé complète.
	 * @return array|null Données du payload (client, email, expires, type) ou null.
	 */
	public static function verify_offline_key( $key ) {
		$key = trim( (string) $key );
		if ( 0 !== strpos( $key, self::KEY_PREFIX ) ) {
			return null;
		}

		$parts = explode( '.', substr( $key, strlen( self::KEY_PREFIX ) ) );
		if ( 2 !== count( $parts ) ) {
			return null;
		}

		$payload = self::b64url_decode( $parts[0] );
		$sig     = self::b64url_decode( $parts[1] );
		// Clé publique Ed25519 : celle de la classe Updater (embarquée dans
		// le plugin et identique à celle des manifests signés). Absente de la
		// build WordPress.org (stub) → les clés hors ligne n'y sont pas
		// supportées, volontairement.
		$pk = ( class_exists( '\InfinityCod\License\Updater' ) && defined( '\InfinityCod\License\Updater::SIGNING_PUBLIC_KEY' ) )
			? base64_decode( \InfinityCod\License\Updater::SIGNING_PUBLIC_KEY, true )
			: false;
		if ( false === $payload || false === $sig || false === $pk ) {
			return null;
		}
		if ( ! self::ed25519_verify( $payload, $sig, $pk ) ) {
			return null;
		}

		$data = json_decode( $payload, true );
		if ( ! is_array( $data ) || empty( $data['expires'] ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $data['expires'] ) ) {
			return null;
		}
		if ( (string) $data['expires'] < gmdate( 'Y-m-d' ) ) {
			return null; // Expirée.
		}
		return $data;
	}

	/**
	 * Vérification Ed25519 : extension sodium, repli sodium_compat de WordPress.
	 *
	 * @param string $msg Message signé.
	 * @param string $sig Signature détachée (octets).
	 * @param string $pk  Clé publique (octets).
	 * @return bool
	 */
	private static function ed25519_verify( $msg, $sig, $pk ) {
		if ( function_exists( 'sodium_crypto_sign_detached_verify' ) ) {
			try {
				return sodium_crypto_sign_detached_verify( $msg, $sig, $pk );
			} catch ( \Throwable $e ) {
				return false;
			}
		}
		if ( ! class_exists( 'ParagonIE_Sodium_Compat' ) && file_exists( ABSPATH . WPINC . '/sodium_compat/autoload.php' ) ) {
			require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
		}
		if ( class_exists( 'ParagonIE_Sodium_Compat' ) ) {
			try {
				return \ParagonIE_Sodium_Compat::crypto_sign_verify_detached( $sig, $msg, $pk );
			} catch ( \Throwable $e ) {
				return false;
			}
		}
		return false;
	}

	/**
	 * Décode du base64-url (tolérant au padding absent).
	 *
	 * @param string $s Chaîne base64url.
	 * @return string|false
	 */
	private static function b64url_decode( $s ) {
		return base64_decode( strtr( rtrim( (string) $s, '=' ), '-_', '+/' ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- décodage de notre propre format signé.
	}

	/**
	 * État de l'essai Premium (7 jours, une seule fois par site).
	 *
	 * @return array{used: bool, until: int, started_at: int}
	 */
	public static function trial() {
		$t = get_option( self::TRIAL_OPTION, array() );
		return is_array( $t ) ? $t : array();
	}

	/**
	 * L'essai gratuit a-t-il déjà été consommé sur ce site ?
	 *
	 * @return bool
	 */
	public static function trial_used() {
		$t = self::trial();
		return ! empty( $t['used'] );
	}

	/**
	 * L'essai gratuit est-il en cours ?
	 *
	 * @return bool
	 */
	public static function trial_active() {
		$t = self::trial();
		return ! empty( $t['until'] ) && (int) $t['until'] > time();
	}

	/**
	 * Jours restants de l'essai (0 si terminé).
	 *
	 * @return int
	 */
	public static function trial_days_left() {
		$t = self::trial();
		if ( empty( $t['until'] ) ) {
			return 0;
		}
		return max( 0, (int) ceil( ( (int) $t['until'] - time() ) / DAY_IN_SECONDS ) );
	}

	/**
	 * Démarre l'essai Premium : tout est débloqué pendant 7 jours,
	 * une seule fois par site, sans carte ni engagement.
	 *
	 * @return array{ok: bool, message: string}
	 */
	public function start_trial() {
		if ( self::trial_active() ) {
			return array( 'ok' => false, 'message' => __( 'L’essai Premium est déjà en cours sur ce site.', 'infinitycod' ) );
		}
		if ( self::trial_used() ) {
			return array( 'ok' => false, 'message' => __( 'L’essai gratuit a déjà été utilisé sur ce site.', 'infinitycod' ) );
		}
		$stored = self::stored();
		if ( ! empty( $stored['key_hash'] ) && in_array( isset( $stored['status'] ) ? $stored['status'] : '', array( 'ACTIVE', 'UNKNOWN' ), true ) ) {
			return array( 'ok' => false, 'message' => __( 'Une licence Premium est déjà active — pas besoin d’essai.', 'infinitycod' ) );
		}

		update_option(
			self::TRIAL_OPTION,
			array(
				'used'       => 1,
				'until'      => time() + self::TRIAL_DAYS * DAY_IN_SECONDS,
				'started_at' => time(),
			),
			false
		);

		return array(
			'ok'      => true,
			/* translators: %d : nombre de jours. */
			'message' => sprintf( __( 'Essai Premium activé : tout est débloqué pendant %d jours 🎉', 'infinitycod' ), self::TRIAL_DAYS ),
		);
	}

	/**
	 * Libellé du statut courant.
	 *
	 * @return string
	 */
	/**
	 * Carte « Go Pro » réutilisable : roadmap Premium + essai + licence.
	 *
	 * Rend une chaîne vide si Premium est actif — la carte ne s'affiche
	 * que pour les installations gratuites.
	 *
	 * @return string HTML de la carte.
	 */
	public static function go_pro_card() {
		if ( self::is_premium() ) {
			return '';
		}

		$checkout = self::checkout_url();

		$features = array(
			__( 'WhatsApp automatique — confirmations, expédition, relances paniers', 'infinitycod' ),
			__( 'Paliers d’offres par quantité personnalisés', 'infinitycod' ),
			__( 'Livraison multi-pays & multi-devises', 'infinitycod' ),
			__( 'Portail de suivi client & facture PDF avancée', 'infinitycod' ),
			__( 'Statistiques avancées & rapports étendus', 'infinitycod' ),
			__( 'Support prioritaire + toutes les futures fonctionnalités Pro', 'infinitycod' ),
		);

		$items = '';
		foreach ( $features as $feature ) {
			$items .= '<span><span class="check">✓</span>' . esc_html( $feature ) . '</span>';
		}

		$trial_used = self::trial_used();
		$trial_btn  = '';
		if ( ! $trial_used ) {
			$trial_btn = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
				. '<input type="hidden" name="action" value="icod_start_trial" />'
				. wp_nonce_field( 'icod_start_trial' )
				. '<button type="submit" class="button button-primary icod-gopro-btn-primary">🚀 ' . esc_html__( 'Essai gratuit 7 jours', 'infinitycod' ) . '</button>'
				. '</form>';
		}

		// Achat direct Freemius : le client paie par carte sur le checkout
		// sécurisé de l'éditeur, reçoit sa clé par email, la colle dans
		// Réglages → Licence. Le bouton ne s'affiche que si le lien existe.
		$buy_btn = '';
		if ( '' !== $checkout ) {
			$buy_btn = '<a class="button button-primary icod-gopro-btn-gold" href="' . esc_url( $checkout ) . '" target="_blank" rel="noopener">💳 ' . esc_html__( 'Acheter Premium — par carte (paiement sécurisé)', 'infinitycod' ) . '</a>';
		}

		$html = '<div class="icod-gopro">'
			. '<div class="icod-gopro-star">★</div>'
			. '<h2><span class="star">★</span> ' . esc_html__( 'Passez à InfinityCod Premium', 'infinitycod' ) . '</h2>'
			. '<p>' . esc_html__( 'Débloquez la feuille de route Pro : WhatsApp automatique, paliers d’offres, multi-pays, support prioritaire — tout en gardant gratuitement chaque fonctionnalité gratuite, pour toujours.', 'infinitycod' ) . '</p>'
			. '<div class="feat">' . $items . '</div>'
			. '<div class="btns">'
			. $buy_btn
			. $trial_btn
			. '<a class="button icod-gopro-btn-gold" href="' . esc_url( admin_url( 'admin.php?page=infinitycod-settings&tab=license' ) ) . '">★ ' . esc_html__( 'Activer une licence', 'infinitycod' ) . '</a>'
			. '</div>'
			. '</div>';

		return $html;
	}

	/**
	 * Lien d'achat Premium (checkout Freemius de l'éditeur).
	 *
	 * Priorité : constante INFINITYCOD_CHECKOUT_URL (gravée dans le build,
	 * donc visible par tous les clients) → réglage vendeur freemius_checkout_url.
	 *
	 * @return string Url du checkout, ou chaîne vide si non configuré.
	 */
	public static function checkout_url() {
		if ( defined( 'INFINITYCOD_CHECKOUT_URL' ) && '' !== trim( (string) INFINITYCOD_CHECKOUT_URL ) ) {
			return trim( (string) INFINITYCOD_CHECKOUT_URL );
		}
		$url = trim( (string) Settings::get( 'freemius_checkout_url', '' ) );
		return ( '' !== $url && 0 === strpos( $url, 'https://' ) ) ? $url : '';
	}

	public static function status_label() {
		if ( self::trial_active() ) {
			/* translators: %d : jours restants. */
			return sprintf( __( 'Essai Premium — %d j restants', 'infinitycod' ), self::trial_days_left() );
		}
		if ( self::is_premium() ) {
			return __( 'Premium actif', 'infinitycod' );
		}
		return __( 'Version gratuite', 'infinitycod' );
	}
}
